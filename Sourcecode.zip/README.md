# ClipResourceDownloader

## Usage

1. Type `pip install -r requirements.txt`
2. Using `python3 main.py video video_link` to download video or using `python3 main.py playlist playlist_link` download playlist
3. If you don't want to use Command-line, you can use GUI(This function will be written ASAP)

## Warning
In now only can download `720p` video  
We still testing `1080p` & `4K`

## Todo
- [ ] Modular
- [ ] Full HD support
- [ ] Add GUI interface
